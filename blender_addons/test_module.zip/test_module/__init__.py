bl_info = {
    "name": "Example Addon Preferences",
    "author": "Your Name Here",
    "version": (1, 0),
    "blender": (2, 65, 0),
    "location": "SpaceBar Search -> Addon Preferences Example",
    "description": "Example Addon",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object"}

sub_modules_names = (
    "pie_object_modes_of",
    "pie_view_of",
    "pie_shade_of",
    "pie_manipulator_of",
    "pie_pivot_of",
    "pie_snap_of",
    "pie_clip_marker_of",
    )




sub_modules = {submod:__import__(__package__ + "." + submod, {}, {}, submod) for submod in sub_modules_names}
#sub_modules.sort(key=lambda mod: (mod.bl_info['category'], mod.bl_info['name']))


def _get_pref_class(mod):
    import inspect

    for obj in vars(mod).values():
        if inspect.isclass(obj) and issubclass(obj, AddonPreferences):
            
            if hasattr(obj, 'bl_idname'):# and obj.bl_idname == mod.__name__:
                return obj
    return None


import bpy
from bpy.types import Operator, AddonPreferences
from bpy.props import StringProperty, IntProperty, BoolProperty


class OBJECT_OT_addon_prefs_example(Operator):
    """Display example preferences"""
    bl_idname = "object.addon_prefs_example"
    bl_label = "Addon Preferences Example"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        user_preferences = context.user_preferences
        addon_prefs = user_preferences.addons[__name__].preferences

        info = ("Path: %s, Number: %d, Boolean %r" %
                (addon_prefs.filepath, addon_prefs.number, addon_prefs.boolean))

        self.report({'INFO'}, info)
        print(info)

        return {'FINISHED'}


from bpy.types import PropertyGroup
from bpy.props import PointerProperty
import rna_keymap_ui
'''
submods = {"submod1": ExampleAddonPreferences,
          "submod2": ExampleAddonPreferences2}
'''

def draw_keymaps(layout, context, module, key="addon_keymaps"):
    addon_keymaps = getattr(module, key, [])
    if not addon_keymaps:
        print(module, "no addon keymaps")
        return
    print("addon keymaps")
    col = layout
    kc = context.window_manager.keyconfigs.addon
    for km, kmi in addon_keymaps:
        km = km.active()
        col.context_pointer_set("keymap", km)
        #kmi.name = kmi.name.encode('utf-8').strip()
        # TODO ERROR UTF decode error on kmi.name
        try: 
            rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
        except:
            pass

def draw_info(module, mod, layout, info, context):
    colsub = layout # TODO FIX
    # sanitize info dic 
    for info_name in ["description", "location", "author", "version", "warning", "wiki_url"]:
        info.setdefault(info_name, "")
    if mod.expand:
        try: # TODO take out sanitize should take care of it.
            if info["description"]:
                split = colsub.row().split(percentage=0.15)
                split.label(text="Description:")
                split.label(text=info["description"])
            if info["location"]:
                split = colsub.row().split(percentage=0.15)
                split.label(text="Location:")
                split.label(text=info["location"])
            if module:
                split = colsub.row().split(percentage=0.15)
                split.label(text="File:")
                split.label(text=module.__file__, translate=False)
            if info["author"]:
                split = colsub.row().split(percentage=0.15)
                split.label(text="Author:")
                split.label(text=info["author"], translate=False)
            if info["version"]:
                split = colsub.row().split(percentage=0.15)
                split.label(text="Version:")
                split.label(text='.'.join(str(x) for x in info["version"]), translate=False)
            if info["warning"]:
                split = colsub.row().split(percentage=0.15)
                split.label(text="Warning:")
                split.label(text='  ' + info["warning"], icon='ERROR')
                tot_row = bool(info["wiki_url"]) # + bool(user_addon)

                if tot_row:
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Internet:")
                    if info["wiki_url"]:
                        split.operator("wm.url_open", text="Documentation", icon='HELP').url = info["wiki_url"]
                    split.operator("wm.url_open", text="Report a Bug", icon='URL').url = info.get(
                            "tracker_url",
                            "https://developer.blender.org/maniphest/task/edit/form/2")

        except KeyError:
            print(KeyError)
                
def draw(self, context):
      
    layout = self.layout
    for k, module in sub_modules.items():
        info = getattr(module, "bl_info", {})
        mod = getattr(self, k)
        box = layout.box()
        row = box.row(align=True)
        row.prop(mod, "expand", icon='TRIA_DOWN' if mod.expand else 'TRIA_RIGHT', icon_only=True, emboss=False)
        row.prop(mod, "enable", icon='CHECKBOX_HLT' if mod.enable else 'CHECKBOX_DEHLT', icon_only=True, emboss=False)
        sub = row.row()
        sub.enabled = mod.enable
        sub.label(info["description"])
        if mod.expand:
            col = box.column()
            draw_info(module, mod, col, info, context)
            if mod.enable and mod.has_prefs:
                box.label("Preferences:")
                modbox = box.box()
                
                mod.layout = modbox
                mod.draw(context)
       
            if mod.enable and module.addon_keymaps:
                col = box.column()
                col.label("Submodule Keymaps:")
                split = col.split(percentage=0.1)
                split.label(" ")
                draw_keymaps(split.column(), context, module)


subaddonprefs = {
                  "bl_idname": "test_module",                 
                  "draw": draw,
                  }
 
def register_submodule(submod):
    mod = sub_modules.get(submod)
    def register(self, context):
        if mod is None:
            return None
        if self.enable:
              sub_modules[submod].register()
              print("%s.register()" % submod)
        else:
              print("%s.unregister()" % submod)

              sub_modules[submod].unregister()
        return None
    return register

classes = []
def create_addon_prefs():                                   
    for submod, mod in sub_modules.items():
        prefsclass = _get_pref_class(mod)
        props = {}
        props["enable"] = BoolProperty(update=register_submodule(submod), default=True, description="Enable %s" % submod)
        props["expand"] = BoolProperty(default=False)
        props["has_prefs"] = prefsclass is not None
        if prefsclass:
            # build a property group from the addonspref class            
            props.update({k:v for k,v in vars(prefsclass).items() if not k.startswith("__")})

        preferences = type("%sPreferences" % submod, (PropertyGroup,), props)
        #classes.append(preferences)
        bpy.utils.register_class(preferences)
        classes.append(preferences)
        subaddonprefs[submod] = PointerProperty(type=preferences)


    # make and addonspref 
    return type("AddonPrefs", (AddonPreferences,), subaddonprefs)

# Registration
from bpy.app.handlers import persistent
@persistent
def handle_registration(dummy):
    
    print("Register the submodules based on prefs")
    if dummy:
        #enable disable addons from prefs
        addon = bpy.context.user_preferences.addons.get(__name__)
        print(addon)
        if addon is None:
            bpy.app.handlers.scene_update_post.remove(handle_registration)
            return None
        prefs = addon.preferences
        for submod, module in sub_modules.items():
            print(prefs)
            mod = getattr(prefs, submod, None)
            if not mod:
                continue
            if getattr(mod, "enable", False) and hasattr(module, "register"):
                try:
                    module.register()
                    print("%s.register()" % submod)

                except RuntimeError:
                    print(RuntimeError)
                    return None  
        bpy.app.handlers.scene_update_post.remove(handle_registration)    
    return None
     
def register():
    classes.clear()
    print("REGISTER")
    addonprefs = create_addon_prefs()
    bpy.utils.register_class(OBJECT_OT_addon_prefs_example)
    try:
        bpy.utils.register_class(addonprefs)
    except ValueError:
        print(ValueError)     

    classes.extend([OBJECT_OT_addon_prefs_example, addonprefs])
    print(classes)
    bpy.app.handlers.scene_update_post.append(handle_registration)
    #bpy.app.handlers.load_post.append(handle_registration)

def unregister():
    print("UNREG CLASSES", classes)
    for cls in classes:
        print("UNREG", cls, hasattr(cls, "bl_rna"))
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            print(RuntimeError)

    classes.clear()
    for mod in sub_modules.values():
        try:
            mod.unregister()
        except RuntimeError:
            print(RuntimeError)

    #bpy.app.handlers.load_post.remove(handle_registration)

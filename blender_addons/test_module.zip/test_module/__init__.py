bl_info = {
    "name": "Example Addon Preferences",
    "author": "batFINGER",
    "version": (1, 0),
    "blender": (2, 77, 0),
    "location": "SpaceBar Search -> Addon Preferences Example",
    "description": "Example Addon",
    "warning": "xxxxx",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Object"}

import bpy
from bpy.types import Operator, AddonPreferences, PropertyGroup
from bpy.props import StringProperty, IntProperty, BoolProperty, PointerProperty


# import the following as "subaddons"
# (name, default_enabled)
sub_modules_names = (
    ("pie_object_modes_of", True),
    ("pie_view_of", True),
    ("pie_shade_of", True),
    ("pie_manipulator_of", True),
    ("pie_pivot_of", True),
    ("pie_snap_of", True),
    ("pie_clip_marker_of", True),
    ("submod1", True),
    )

addons = {}

def draw(self, context):
    layout = self.layout
    for subaddon in addons.values():
        module = subaddon.module
        info = subaddon.info
        mod = getattr(self, subaddon.name, None)
        box = layout.box()
        subaddon.draw(box, context)

class SubAddon:
    @property
    def _store(self):
        addon = bpy.context.user_preferences.addons.get(__package__)
        prefs = getattr(addon, "preferences", None)
        return getattr(prefs, self.name, None)

    def register_submodule(self):
        module = self.module
        name = self.name
        def register(self, context):
            if module is None:
                return None
            if self.enable:
                module.register()
                print("%s.register()" % name)
            else:
                print("%s.unregister()" % name)
                module.unregister()
            return None
        return register

    def _get_pref_class(self):
        import inspect
        for obj in vars(self.module).values():
            if inspect.isclass(obj) and issubclass(obj, AddonPreferences):
                if hasattr(obj, 'bl_idname'):# and obj.bl_idname == mod.__name__:
                    return obj
        return None

    @property
    def enabled(self):
        store = self._store
        if store:
            return getattr(store, "enable")
        return None

    @enabled.setter
    def enabled(self, value):
        store = self._store
        if self._store:
            setattr(self._store, "enable", value)

    @property
    def preferences(self):
        if self.prefsclass:
            return getattr(self._store, "preferences", None)
        return None

    def register(self):
        pass

    def unregister(self):
        pass

    # TODO wire this in maybe
    def draw_keymaps(self, layout, context, module, key="addon_keymaps"):
        import rna_keymap_ui
        addon_keymaps = getattr(module, key, [])
        col = layout
        kc = context.window_manager.keyconfigs.addon
        for km, kmi in addon_keymaps:
            km = km.active()
            col.context_pointer_set("keymap", km)
            #kmi.name = kmi.name.encode('utf-8').strip()
            # TODO ERROR UTF decode error on kmi.name
            try: 
                rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
            except:
                pass

    def draw_info(self, layout, context):
        store = self._store
        colsub = layout # TODO FIX
        # sanitize info dic 
        
        for info_name in ["description", "location", "author", "version", "warning", "wiki_url"]:
            self.info.setdefault(info_name, "")
        if store.expand:
            info = self.info
            try: # TODO take out sanitize should take care of it.
                if info.get("description"):
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Description:")
                    split.label(text=info["description"])
                if info.get("location"):
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Location:")
                    split.label(text=info["location"])
                if self.module:
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="File:")
                    split.label(text=self.module.__file__, translate=False)
                if info.get("author"):
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Author:")
                    split.label(text=info["author"], translate=False)
                if info.get("version"):
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Version:")
                    split.label(text='.'.join(str(x) for x in info["version"]), translate=False)
                if info.get("warning"):
                    split = colsub.row().split(percentage=0.15)
                    split.label(text="Warning:")
                    split.label(text='  ' + info["warning"], icon='ERROR')
                    tot_row = bool(info.get("wiki_url")) # + bool(user_addon)

                    if tot_row:
                        split = colsub.row().split(percentage=0.15)
                        split.label(text="Internet:")
                        if info.get("wiki_url"):
                            split.operator("wm.url_open", text="Documentation", icon='HELP').url = info["wiki_url"]
                        split.operator("wm.url_open", text="Report a Bug", icon='URL').url = info.get(
                                "tracker_url",
                                "https://developer.blender.org/maniphest/task/edit/form/2")

            except KeyError:
                # shouldn't happen
                print(KeyError)

    def draw(self, layout, context):
        row = layout.row(align=True)

        store = self._store
        row.prop(store, "expand", icon='TRIA_DOWN' if store.expand else 'TRIA_RIGHT', icon_only=True, emboss=False)
        row.prop(store, "enable", icon='CHECKBOX_HLT' if self.enabled else 'CHECKBOX_DEHLT', icon_only=True, emboss=False)
        sub = row.row()
        sub.enabled = store.enable
        sub.label(self.info["description"])
        if store.expand:
            self.draw_info(layout.column(), context)
            #layout.label("%s %s" % (store.enable, store.has_prefs))
            if store.enable and store.has_prefs:
                layout.label("Preferences:")
                modbox = layout.box()
                
                pref = getattr(store, "preferences")
                pref.layout = modbox
                pref.draw(context)


    def __init__(self, name):
        self.name = name
        module = __import__("%s.%s" % (__package__, name), {}, {}, name)
        self.module = module
        self.info = getattr(self.module, "bl_info", {})
        self.prefsclass = self._get_pref_class()

classes = []
def create_addon_prefs():                                   
    # TODO move into class def

    subaddonprefs = {
                  "bl_idname": "test_module",                 
                  "draw": draw,
                  "addons": {}
                  }

    for name, default_enabled in sub_modules_names:
        subaddon = SubAddon(name)
        mod = subaddon.module
        prefsclass = subaddon.prefsclass
        props = {}
        props["enable"] = BoolProperty(update=subaddon.register_submodule(), default=default_enabled, description="Enable %s" % name)
        props["expand"] = BoolProperty(default=False)
        props["has_prefs"] = prefsclass is not None
        if prefsclass:
            # build a property group from the addonspref class            
            addonprefs = type("%sAddonPreferences" % name, (PropertyGroup,), {k:v for k,v in vars(prefsclass).items() if not k.startswith("__")})
            #addonprefs.layout = None
            bpy.utils.register_class(addonprefs)
            props["preferences"] = PointerProperty(type=addonprefs)

        preferences = type("%sPreferences" % name, (PropertyGroup,), props)
        #classes.append(preferences)
        bpy.utils.register_class(preferences)
        classes.append(preferences)
        subaddonprefs[name] = PointerProperty(type=preferences)
        subaddonprefs["addons"][name] = subaddon
        addons[name] = subaddon


    # make an addonspref 
    return type("AddonPrefs", (AddonPreferences,), subaddonprefs)


class OBJECT_OT_addon_prefs_example(Operator):
    """Display example preferences"""
    bl_idname = "object.addon_prefs_example"
    bl_label = "Addon Preferences Example"
    bl_options = {'REGISTER', 'UNDO'}
    subaddon = StringProperty(default="", options={'SKIP_SAVE'})

    def execute(self, context):
        user_preferences = context.user_preferences
        addon_prefs = user_preferences.addons[__package__].preferences
        if self.subaddon:

            subaddon_prefs = addon_prefs.addons[self.subaddon].preferences
            info = ("Path: %s, Number: %d, Boolean %r" %
                (addon_prefs.filepath, addon_prefs.number, addon_prefs.boolean))

            self.report({'INFO'}, info)

        return {'FINISHED'}


# Registration
def handle_registration(dummy):
    if dummy:
        #enable disable addons from prefs
        addon = bpy.context.user_preferences.addons.get(__name__)
        prefs = addon.preferences
        for name, subaddon in addons.items():
            subaddon.register_submodule()
    return None
     
def register():
    classes.clear()
    addonprefs = create_addon_prefs()
    bpy.utils.register_class(OBJECT_OT_addon_prefs_example)
    bpy.utils.register_class(addonprefs)
    classes.extend([OBJECT_OT_addon_prefs_example, addonprefs])
    handle_registration(True)

def unregister():
    for cls in classes:
        if hasattr(cls, "bl_rna"):
            bpy.utils.unregister_class(cls)

    classes.clear()
    addons.clear()
